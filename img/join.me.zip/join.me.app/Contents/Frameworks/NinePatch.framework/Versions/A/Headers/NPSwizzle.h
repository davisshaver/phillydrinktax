/*
 *  NPSwizzle.h
 *  IRVHost
 *
 *  Created by Karoly Lorentey on 2011-04-20.
 *  Copyright 2011 LogMeIn, Inc. All rights reserved.
 *
 */

// Exchange the implementations of method1 and method2 in class.
extern BOOL NPSwizzleMethods(Class cls, SEL method1, SEL method2);
