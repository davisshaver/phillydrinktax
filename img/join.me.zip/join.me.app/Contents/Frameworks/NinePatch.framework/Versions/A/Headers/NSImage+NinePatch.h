//
//  NSImage+NinePatch.h
//  ninepatch
//
//  Created by Károly Lőrentey on 2012-01-29.
//  Copyright (c) 2012 LogMeIn, Inc. All rights reserved.
//

#import <AppKit/AppKit.h>

@interface NSImage (NinePatch)

// Calls imageWithSize:flipped:drawingHandler: on 10.8; creates a single 1x image rep on 10.7 and below.
+ (id)npImageWithSize:(NSSize)size flipped:(BOOL)drawingHandlerShouldBeCalledWithFlippedContext drawingHandler:(BOOL (^)(NSRect dstRect))drawingHandler;

- (NSImage *)npDesaturatedImage;
- (NSImage *)npHighlightedImage;
@end
