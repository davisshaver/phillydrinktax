//
//  NPStyleable.h
//  ninepatch
//
//  Created by Károly Lőrentey on 2013-05-05.
//  Copyright (c) 2013 LogMeIn, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol NPStyleable <NSObject>


//   return @{@"state": @{@(NPMenuItemStateNormal): @"",
//                        @(NPMenuItemStateHighlighted): @"highlighted",
//                        @(NPMenuItemStateDisabled): @"disabled"},
//            @"size": @{@(NPMenuItemSizeSmall): @"small",
//                       @(NPMenuItemSizeNormal): @"",
//                       @(NPMenuItemSizeLarge): @"large"}]];
+ (NSDictionary *)styleStates;

- (id<NPStyleable>)styleParent;
@property (nonatomic, strong) NSString *styleContext;


@end
