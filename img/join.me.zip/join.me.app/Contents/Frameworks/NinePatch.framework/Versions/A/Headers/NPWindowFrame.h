//
//  NPWindowFrame.h
//  ninepatch
//
//  Created by Karoly Lorentey on 2011-05-19.
//  Copyright 2011 LogMeIn, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <ninepatch/NPView.h>
#import <ninepatch/NPClickThroughController.h>

typedef NS_OPTIONS(int, NPResizeMask) {
    NPResizeByNoEdge = 0,
    NPResizeByLeftEdge = 1,
    NPResizeByRightEdge = 2,
    NPResizeByTopEdge = 4,
    NPResizeByBottomEdge = 8,
    NPResizeByAllEdges = 15
};

@class NPMask;

@protocol NPWindowFrameDelegate;

// Implements ninepatch-based window frames for managing window appearance and resize operations.
@interface NPWindowFrame : NPView

@property (nonatomic, assign, getter = isDraggable) BOOL draggable;

@property (nonatomic, assign) NPResizeMask resizeMask;
@property (nonatomic, assign) NPEdgeInsets resizeInsets;

@property (nonatomic, readonly, getter=isResizing) BOOL resizing;
@property (nonatomic, readonly) NPPatch resizePatch;

@property (nonatomic, readonly) NPEdgeInsets visualInsets;

// Title view support
@property (nonatomic, strong) NSView *titleView;
@property (nonatomic, assign) NPEdgeInsets titleInsets;

@property (nonatomic, unsafe_unretained) id<NPWindowFrameDelegate> delegate;
@end

@protocol NPWindowFrameDelegate<NSObject>
- (void)windowFrameParametersDidChange:(NPWindowFrame *)windowFrame
                     fromContentInsets:(NPEdgeInsets)oldInsets
                       toContentInsets:(NPEdgeInsets)newInsets;

- (void)startDraggingWindow;
- (void)dragWindowToVisualOrigin:(NSPoint)origin;
- (void)endDraggingWindow;
@end

