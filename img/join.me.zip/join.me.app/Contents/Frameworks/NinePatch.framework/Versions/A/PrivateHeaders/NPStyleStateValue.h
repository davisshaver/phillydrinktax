//
//  NPStyleStateValue.h
//  ninepatch
//
//  Created by Karoly Lorentey on 2013-05-09.
//  Copyright (c) 2013 LogMeIn, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

// A simple NSDictionary wrapper that has a nontrivial implementation of -[NSObject hash].
//
// We need this because -[NSDictionary hash] simply returns the item count,
// leading to frequent hash collisions when a dictionary is used as a key in another dictionary.
//
@interface NPStyleStateValue : NSObject<NSCopying, NSFastEnumeration>

+ (NPStyleStateValue *)stateValue;
+ (NPStyleStateValue *)stateValueWithDictionary:(NSDictionary *)dictionary;

- (NSUInteger)count;
- (id)objectForKey:(id)aKey;
- (id)objectForKeyedSubscript:(id)key;
- (void)enumerateKeysAndObjectsUsingBlock:(void (^)(NSString *name, id<NSCopying> value, BOOL *stop))block;
- (void)enumerateKeysAndObjectsWithOptions:(NSEnumerationOptions)opts usingBlock:(void (^)(NSString *name, id<NSCopying> value, BOOL *stop))block;

// Mutability methods.
// Note that you can only add new keys, and only until the object is first copied.
- (void)setObject:(id<NSCopying>)object forKey:(id<NSCopying>)key;
- (void)setObject:(id<NSCopying>)object forKeyedSubscript:(id<NSCopying>)key;

@end
