//
//  NPSecureTextFieldCell.h
//  ninepatch
//
//  Created by Karoly Lorentey on 2011-05-09.
//  Copyright 2011 LogMeIn, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <ninepatch/NPNinePatch.h>

// A subclass of NSSecureTextFieldCell that draws a nine patch image as its background.
// The text is drawn inside the image's contents area.
@interface NPSecureTextFieldCell : NSSecureTextFieldCell
@property (nonatomic, strong) NPNinePatch *ninePatch;

@end
