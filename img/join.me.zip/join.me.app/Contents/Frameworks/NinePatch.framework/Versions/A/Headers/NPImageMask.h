//
//  NPImageMask.h
//  mac_frontend
//
//  Created by Károly Lőrentey on 2012-03-11.
//  Copyright (c) 2012 LogMeIn, Inc. All rights reserved.
//

// An image class whose instances can draw themselves in any color.
// Note that image masks aren't usually resizable; they expect to be drawn at their native size.
@interface NPImageMask : NSObject<NSCopying>

// Loads the named image resource and caches the result. The image must have a grayscale color space.
+ (NPImageMask *)imageMaskNamed:(NSString *)name;

// Simply wraps an NSImage into an NPImageMask. The image is used as is; no coloration is done.
// This is useful when you want to place a full color icon into something that expects a monochrome one.
+ (NPImageMask *)imageMaskWithConstantImage:(NSImage *)image;

// Renders a string using a particular font and uses that as the image. Useful for symbols.
+ (NPImageMask *)imageMaskWithString:(NSString *)string font:(NSFont *)font;

+ (NPImageMask *)imageMaskWithAttributedString:(NSAttributedString *)string;
+ (NPImageMask *)imageMaskWithGlyphname:(NSString *)glyphName inFont:(NSFont *)font;

@property (nonatomic, assign, readonly) CGSize size;

// Renders the image mask into dstRect with the given color.
// The destination rectangle should have the same size as the image.
- (void)drawInRect:(CGRect)dstRect withColor:(NSColor *)color;
- (void)drawInRect:(CGRect)dstRect withColor:(NSColor *)color operation:(NSCompositingOperation)op;
- (void)drawInRect:(CGRect)dstRect withColor:(NSColor *)color operation:(NSCompositingOperation)op alpha:(CGFloat)alpha;


// Produces an NSImage from this image mask using a particular color.
- (NSImage *)bakedImageWithColor:(NSColor *)color;
- (NSImage *)bakedImageWithColor:(NSColor *)color memoize:(BOOL)memoize;

@end
