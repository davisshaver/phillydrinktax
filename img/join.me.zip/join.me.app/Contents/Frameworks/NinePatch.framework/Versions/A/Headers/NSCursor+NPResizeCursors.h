//
//  NSCursor+NPResizeCursors.h
//  ninepatch
//
//  Created by Karoly Lorentey on 2011-05-20.
//  Copyright 2011 LogMeIn, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSCursor (NPResizeCursors)
// Lion-like window resize cursors
+ (NSCursor *)npResizeLeftRightCursor;
+ (NSCursor *)npResizeUpDownCursor;
+ (NSCursor *)npResizeLeftCursor;
+ (NSCursor *)npResizeRightCursor;
+ (NSCursor *)npResizeUpCursor;
+ (NSCursor *)npResizeDownCursor;
+ (NSCursor *)npResizeNESWCursor;
+ (NSCursor *)npResizeNWSECursor;
+ (NSCursor *)npResizeNECursor;
+ (NSCursor *)npResizeNWCursor;
+ (NSCursor *)npResizeSWCursor;
+ (NSCursor *)npResizeSECursor;
@end
