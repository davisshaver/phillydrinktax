//
//  NPStyleState.h
//  ninepatch
//
//  Created by Karoly Lorentey on 2013-05-09.
//  Copyright (c) 2013 LogMeIn, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

// Describes a state selector of a styleable class. States must be KVC-compatible.
// Style sheet entries can be specified to apply only on instances with particular values for a set of states.
// 
@interface NPStyleState : NSObject<NSCopying>

+ (instancetype)stateWithClass:(Class)styleClass
                          name:(NSString *)name
                   namedValues:(NSDictionary *)namedValues;

@property (nonatomic, strong, readonly) Class styleClass;
@property (nonatomic, strong, readonly) NSString *name;

@property (nonatomic, strong, readonly) NSDictionary *namedValues;
- (id)valueForName:(NSString *)valueName;

- (void)addReferencedValue:(id<NSCopying>)value;
- (BOOL)isValueReferenced:(id<NSCopying>)value;
@end
