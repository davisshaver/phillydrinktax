//
//  NPMask.h
//  ninepatch
//
//  Created by Karoly Lorentey on 2011-05-18.
//  Copyright 2011 LogMeIn, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

// A nine patch mask can be used to sample the alpha channel of a nine patch image at individual positions.
// The content area of the nine patch image is assumed to specify the bounding rectangle for pixels with non-zero alpha.
@interface NPMask : NSObject

@property (nonatomic, readonly) NPNinePatch *ninePatch;

+ (NPMask *)maskNamed:(NSString *)name;
+ (NPMask *)maskWithNinePatch:(NPNinePatch *)ninePatch;

- (id)initWithNinePatch:(NPNinePatch *)ninePatch;

// Returns the alpha value for LOCATION when the mask is scaled to RECT.
- (CGFloat)maskValueForLocation:(NSPoint)location inRect:(NSRect)rect;

// The bounding rectangle for pixels with non-zero alpha. (A.k.a. the nine patch content area.)
- (NSRect)maskBoundsForRect:(NSRect)rect;
- (NPEdgeInsets)maskInsets;

@end
