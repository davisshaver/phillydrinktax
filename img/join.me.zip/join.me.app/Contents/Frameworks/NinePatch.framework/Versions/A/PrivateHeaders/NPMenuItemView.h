//
//  NPMenuItemView.h
//  ninepatch
//
//  Created by Károly Lőrentey on 2013-04-24.
//  Copyright (c) 2013 LogMeIn, Inc. All rights reserved.
//

@class NPMenuItem;

@interface NPMenuItemView : NSView
@property (nonatomic, unsafe_unretained, readonly) NPMenuItem *menuItem;
- (id)initWithMenuItem:(NPMenuItem *)menuItem;
@end
