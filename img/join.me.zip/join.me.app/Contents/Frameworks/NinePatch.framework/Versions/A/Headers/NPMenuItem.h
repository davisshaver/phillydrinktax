//
//  NPMenuItem.h
//  ninepatch
//
//  Created by Károly Lőrentey on 2013-04-26.
//  Copyright (c) 2013 LogMeIn, Inc. All rights reserved.
//

#import <NinePatch/NPStyleable.h>

typedef NS_ENUM(NSUInteger, NPMenuItemState) {
    NPMenuItemStateDefault,
    NPMenuItemStateHighlighted,
    NPMenuItemStateDisabled,
};

extern NSString *const NPStyleAttributeNinePatch;
extern NSString *const NPStyleAttributeBackgroundColor;
extern NSString *const NPStyleAttributeForegroundColor;
extern NSString *const NPStyleAttributeFont;

extern NSString *const NPStyleAttributeMenuItemIndentationUnit;

extern NSString *const NPStyleAttributeMenuItemStateInsets;
extern NSString *const NPStyleAttributeMenuItemStateWidth;
extern NSString *const NPStyleAttributeMenuItemOnStateIndicator;
extern NSString *const NPStyleAttributeMenuItemOffStateIndicator;
extern NSString *const NPStyleAttributeMenuItemMixedStateIndicator;

extern NSString *const NPStyleAttributeMenuItemIconInsets;
extern NSString *const NPStyleAttributeMenuItemTitleInsets;
extern NSString *const NPStyleAttributeMenuItemModifierInsets;
extern NSString *const NPStyleAttributeMenuItemTagInsets;

extern NSString *const NPStyleAttributeMenuItemSubmenuIndicator;
extern NSString *const NPStyleAttributeMenuItemSubmenuIndicatorImageMask;
extern NSString *const NPStyleAttributeMenuItemSubmenuIndicatorInsets;

@interface NPMenuItem : NSMenuItem<NPStyleable>

#pragma mark Properties

@property (nonatomic, strong) NPImageMask *iconImageMask;
@property (nonatomic, strong) NPImageMask *tagImageMask; // Takes the place of the key equivalent if present
@property (nonatomic, strong) NPImageMask *onStateImageMask; // Defaults to onStateImage
@property (nonatomic, strong) NPImageMask *offStateImageMask; // Defaults to offStateImage
@property (nonatomic, strong) NPImageMask *mixedStateImageMask; // Defaults to mixedStateImage

@property (nonatomic, assign) BOOL closesMenuOnSelect; // Defaults to YES

#pragma mark Layout and rendering

@property (nonatomic, assign, readonly) NPMenuItemState npState;
@property (assign, getter = isHighlighted) BOOL highlighted; // Inherited, redeclared as assign instead of readonly
@property (nonatomic, copy) dispatch_block_t actionBlock;

- (void)setNeedsLayout;
- (void)layoutIfNeeded;
- (void)layout;

- (CGFloat)keyEquivalentWidth;
- (CGSize)minimumSize;
- (void)drawRect:(NSRect)dirtyRect inView:(NSView *)view;
- (NSDictionary *)textAttributes;

#pragma mark - Utilities

+ (NSString *)stringForKeyEquivalent:(NSString *)keyEquivalent;
+ (NSString *)stringForModifierMask:(NSUInteger)modifierMask;

@end
