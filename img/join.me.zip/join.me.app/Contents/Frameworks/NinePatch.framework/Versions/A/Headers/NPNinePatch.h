//
//  NPNinePatch.h
//  ninepatch
//
//  Created by Károly Lőrentey on 2011-06-08.
//  Copyright 2011 LogMeIn, Inc. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import <ninepatch/NPUtil.h>

// Represents a free scalable nine part image with optional retina support.
//
// The loader methods support the following file formats:
//
//      - *.9pi:   flat, binary nine part image file (See NPNinePatch+FlatFormat.h)
//      - *.9p:    nine part image package (See NPNinePatch+PackageFormat.h)
//      - *.9.png: legacy nine patch format w/o retina support (See NPNinePatch+Deprecated.h)
@interface NPNinePatch : NSObject
@property (nonatomic, readonly) CGImageRef CGImage;
@property (nonatomic, readonly) CGImageRef CGImage2x;

@property (nonatomic, readonly) NPEdgeInsets centerInsets;
@property (nonatomic, readonly) NPEdgeInsets contentInsets;
@property (nonatomic, readonly) NPEdgeInsets maskInsets;
@property (nonatomic, readonly) BOOL tileCenterVertically;
@property (nonatomic, readonly) BOOL tileCenterHorizontally;

@property (nonatomic, readonly) CGSize nativeSize;
@property (nonatomic, readonly) CGRect centerRect;
@property (nonatomic, readonly) CGRect contentRect;

// Looks for the named nine patch resource in the main bundle.
// The file extension may be omitted from the name. The result is memoized.
+ (NPNinePatch *)ninePatchNamed:(NSString *)name;

// Loads the named nine patch asset from the given URL. Expects a correct file extension.
+ (NPNinePatch *)ninePatchWithURL:(NSURL *)URL;

// Constructs a new nine patch image from scratch.
+ (NPNinePatch *)ninePatchWithCGImage:(CGImageRef)cgimage
                            CGImage2x:(CGImageRef)cgimage2x
                         centerInsets:(NPEdgeInsets)centerInsets
                        contentInsets:(NPEdgeInsets)contentInsets
                           maskInsets:(NPEdgeInsets)maskInsets
                 tileCenterVertically:(BOOL)tileCenterVertically
               tileCenterHorizontally:(BOOL)tileCenterHorizontally;

- (CGSize)sizeForContentOfSize:(CGSize)contentSize;
- (CGRect)rectToDrawForContentRect:(CGRect)contentRect;

- (CGSize)contentSizeWhenDrawnInSize:(CGSize)size;
- (CGRect)contentRectWhenDrawnInRect:(CGRect)rect;

- (void)drawInContext:(CGContextRef)c inRect:(CGRect)rect;
- (void)drawInContext:(CGContextRef)c inRect:(CGRect)rect blendMode:(CGBlendMode)blendMode alpha:(CGFloat)alpha;

// These methods return the bottom left corner of the content rectangle.
- (CGPoint)drawInContext:(CGContextRef)c atPoint:(CGPoint)point forContentOfSize:(CGSize)contentSize;
- (CGPoint)drawInContext:(CGContextRef)c centeredInRect:(CGRect)rect forContentOfSize:(CGSize)contentSize;
@end

#if TARGET_OS_MAC
@class NSImage;
@interface NPNinePatch (Mac)
- (void)drawRespectingFlippedInRect:(CGRect)rect blendMode:(CGBlendMode)blendMode alpha:(CGFloat)alpha;

- (NPNinePatch *)desaturatedNinePatch;
- (NPNinePatch *)highlightedNinePatch;

- (NSImage *)image;
+ (NPNinePatch *)ninePatchWithImage:(NSImage *)image
                       centerInsets:(NPEdgeInsets)centerInsets
                      contentInsets:(NPEdgeInsets)contentInsets
                         maskInsets:(NPEdgeInsets)maskInsets
               tileCenterVertically:(BOOL)tileCenterVertically
             tileCenterHorizontally:(BOOL)tileCenterHorizontally;
@end
#endif

