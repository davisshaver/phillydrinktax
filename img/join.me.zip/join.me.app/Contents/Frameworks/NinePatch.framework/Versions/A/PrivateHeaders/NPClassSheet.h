//
//  NPClassSheet.h
//  ninepatch
//
//  Created by Karoly Lorentey on 5/12/13.
//  Copyright (c) 2013 LogMeIn, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@class NPStyle;
@class NPStyleSheetEntry;
@class NPStyleState;

@interface NPClassSheet : NSObject

- (id)initWithOwner:(NPStyleSheet *)owner supersheet:(NPClassSheet *)supersheet styleClass:(Class)styleClass;

@property (nonatomic, unsafe_unretained, readonly) NPStyleSheet *owner;
@property (nonatomic, unsafe_unretained, readonly) NPClassSheet *supersheet;
@property (nonatomic, strong, readonly) Class styleClass;

- (NPStyleState *)stateWithName:(NSString *)name;
- (NPStyleStateValue *)stateValueFromValueNames:(NSArray *)valueNames;

- (void)addSubsheet:(NPClassSheet *)sheet;
- (void)addEntry:(NPStyleSheetEntry *)entry;

- (NSArray *)entriesForContext:(NSString *)context;

- (void)clearCache;
- (NPStyle *)styleForContext:(NSString *)context state:(NPStyleStateValue *)state;
- (NPStyle *)styleForObject:(id<NPStyleable>)object;

@end
