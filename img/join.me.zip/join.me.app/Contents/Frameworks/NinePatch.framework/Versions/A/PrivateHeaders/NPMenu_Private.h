//
//  NPMenu_Private.h
//  ninepatch
//
//  Created by Károly Lőrentey on 2013-05-15.
//  Copyright (c) 2013 LogMeIn, Inc. All rights reserved.
//

#import <NinePatch/NinePatch.h>

@class NPStyle;
@class NPMenuItem;

extern const CGFloat NPMenuStandardCapHeight;
extern const CGFloat NPMenuPopoverArrowWidth;
extern const CGFloat NPMenuPopoverArrowHeight;

@interface NPMenu ()
// These are called by NPMenuDelegate
- (void)npWillOpen;
- (void)npDidClose;
- (void)npWillHighlightItem:(NSMenuItem *)item;

- (void)npCloseAndPerformActionForItem:(NPMenuItem *)item;

@property (nonatomic, readonly) NSColor *backgroundColor;

@end
