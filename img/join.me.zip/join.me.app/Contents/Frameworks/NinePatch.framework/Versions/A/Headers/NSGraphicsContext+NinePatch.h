//
//  NSGraphicsContext+NinePatch.h
//  ninepatch
//
//  Created by Károly Lőrentey on 2013-05-19.
//  Copyright (c) 2013 LogMeIn, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSGraphicsContext (NinePatch)

+ (void)npDrawDebugHighlightInRect:(CGRect)rect;

@end
