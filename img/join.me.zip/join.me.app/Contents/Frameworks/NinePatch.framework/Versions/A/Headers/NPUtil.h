/*
 *  NPUtil.h
 *  ninepatch
 *
 *  Created by Karoly Lorentey on 2011-04-05.
 *  Copyright 2011 LogMeIn, Inc. All rights reserved.
 *
 */


#ifdef __cplusplus
#define NINEPATCH_EXTERN_BEGIN extern "C" {
#define NINEPATCH_EXTERN_END }
#else
#define NINEPATCH_EXTERN_BEGIN
#define NINEPATCH_EXTERN_END
#endif

#define NP_DEPRECATED(msg) __attribute__((deprecated(msg)))

NINEPATCH_EXTERN_BEGIN

#if TARGET_OS_IPHONE // Use iOS/CG geometry types
typedef UIEdgeInsets NPEdgeInsets;

#define NPEdgeInsetsZero UIEdgeInsetsZero
#define NPEdgeInsetsMake UIEdgeInsetsMake
#define NSStringFromNPEdgeInsets NSStringFromUIEdgeInsets

#define NSStringFromNPPoint NSStringFromCGPoint
#define NSStringFromNPSize NSStringFromCGSize
#define NSStringFromNPRect NSStringFromCGRect

#elif TARGET_OS_MAC // Use AppKit geometry types

typedef struct {
	CGFloat top;
	CGFloat left;
	CGFloat bottom;
	CGFloat right;
} NPEdgeInsets;
extern const NPEdgeInsets NPEdgeInsetsZero;

static inline NPEdgeInsets NPEdgeInsetsMake(CGFloat top, CGFloat left, CGFloat bottom, CGFloat right)
{
    NPEdgeInsets insets;
    insets.top = top;
    insets.left = left;
    insets.bottom = bottom;
    insets.right = right;
    return insets;
}

static inline NPEdgeInsets NPEdgeInsetsMakeConstant(CGFloat inset)
{
    return (NPEdgeInsets){ inset, inset, inset, inset };
}

extern NSString *NSStringFromNPEdgeInsets(NPEdgeInsets insets);

#define NSStringFromNPPoint NSStringFromPoint
#define NSStringFromNPSize NSStringFromSize
#define NSStringFromNPRect NSStringFromRect

#else
#error Unknown target OS
#endif
    
static inline int clamp(int value, int min, int max)
{
    int t1 = (value < max ? value : max);
    return (t1 > min ? t1 : min);
}

static inline float clampf(float value, float min, float max)
{
    return fminf(fmaxf(value, min), max);
}

static inline double clampd(double value, double min, double max)
{
    return fmin(fmax(value, min), max);
}

// Linear interpolation between x and y.
static inline float mixf(float x, float y, float t)
{
    return x * (1 - t) + y * t;
}

static inline double mixd(double x, double y, double t)
{
    return x * (1 - t) + y * t;
}

// Like NSRectIntegral but returns the largest rectangle inside rect.
extern CGRect NPRectIntegralInner(CGRect rect);

// Flip x and y coordinates in rect.
extern CGRect NPRectFlip(CGRect rect);
    
static inline BOOL NPEdgeInsetsEqual(NPEdgeInsets insetsA, NPEdgeInsets insetsB)
{
    return (insetsA.top == insetsB.top
            && insetsA.left == insetsB.left
            && insetsA.bottom == insetsB.bottom
            && insetsA.right == insetsB.right);
}

static inline NPEdgeInsets
NPEdgeInsetsScale(NPEdgeInsets insets, CGFloat xScale, CGFloat yScale)
{
    return NPEdgeInsetsMake(yScale * insets.top, xScale * insets.left, 
                            yScale * insets.bottom, xScale * insets.right);
}

static inline NPEdgeInsets
NPEdgeInsetsAdd(NPEdgeInsets insets1, NPEdgeInsets insets2)
{
    return NPEdgeInsetsMake(insets1.top + insets2.top,
                            insets1.left + insets2.left,
                            insets1.bottom + insets2.bottom,
                            insets1.right + insets2.right);
}

static inline NPEdgeInsets
NPEdgeInsetsSubtract(NPEdgeInsets insets1, NPEdgeInsets insets2)
{
    return NPEdgeInsetsMake(insets1.top - insets2.top,
                            insets1.left - insets2.left,
                            insets1.bottom - insets2.bottom,
                            insets1.right - insets2.right);
}

extern NPEdgeInsets NPEdgeInsetsFromInnerRect(CGRect outer, CGRect inner);
extern CGRect NPRectInset(CGRect rect, NPEdgeInsets insets);
extern CGRect NPRectOutset(CGRect rect, NPEdgeInsets insets);
extern CGRect NPRectScale(CGRect rect, CGFloat xScale, CGFloat yScale);

extern CGSize NPSizeInset(CGSize size, NPEdgeInsets insets);
extern CGSize NPSizeOutset(CGSize size, NPEdgeInsets insets);
extern CGSize NPSizeScale(CGSize size, CGFloat xScale, CGFloat yScale);

typedef enum {
	NPPatchTopLeft = 0,
	NPPatchTop,
	NPPatchTopRight,
	NPPatchLeft,
	NPPatchCenter,
	NPPatchRight,
	NPPatchBottomLeft,
	NPPatchBottom,
	NPPatchBottomRight,
	NPPatchLIMIT
} NPPatch;

extern BOOL NPPatchStretchesHorizontally(NPPatch patch);
extern BOOL NPPatchStretchesVertically(NPPatch patch);
extern CGRect NPPatchGetRect(CGRect rect, NPEdgeInsets insets, NPPatch patch);
extern NPPatch NPRectGetPatch(CGRect rect, NPEdgeInsets insets, CGPoint point);

extern CGPoint NPRectAnchorPoint(CGRect rect, NPPatch anchorPatch);
extern CGRect NPSizeAlignToAnchor(CGSize size, CGPoint location, NPPatch anchorPatch);    
extern CGRect NPRectAlignToAnchor(CGRect rect, CGPoint location, NPPatch anchorPatch);

static inline CGPoint
NPRectGetRelativePosition(CGRect rect, CGFloat relativeX, CGFloat relativeY)
{
    return CGPointMake(CGRectGetMinX(rect) + relativeX * CGRectGetWidth(rect),
                       CGRectGetMinY(rect) + relativeY * CGRectGetHeight(rect));
}

static inline CGRect
NPSizeAlignToRect(CGSize size, NPPatch sizePatch, CGRect rect, NPPatch rectPatch)
{
    return NPSizeAlignToAnchor(size, NPRectAnchorPoint(rect, rectPatch), sizePatch);
}

// Return the rectangle closest to rect that fits in frame.  May resize rect if frame is smaller.
extern CGRect NPRectClosestInFrame(CGRect rect, CGRect frame);

static inline CGSize NPSizeBetween(CGPoint pointEnd, CGPoint pointStart)
{
    return CGSizeMake(pointEnd.x - pointStart.x,
                      pointEnd.y - pointStart.y);
}

static inline CGSize NPSizeMax(CGSize sizeA, CGSize sizeB)
{
    return CGSizeMake(fmax(sizeA.width, sizeB.width), 
                      fmax(sizeA.height, sizeB.height));
}

static inline CGSize NPSizeMin(CGSize sizeA, CGSize sizeB)
{
    return CGSizeMake(fmin(sizeA.width, sizeB.width), 
                      fmin(sizeA.height, sizeB.height));
}

static inline CGSize NPSizeAdd(CGSize sizeA, CGSize sizeB)
{
    return CGSizeMake(sizeA.width + sizeB.width, sizeA.height + sizeB.height);
}

static inline CGSize NPSizeSubtract(CGSize sizeA, CGSize sizeB)
{
    return CGSizeMake(sizeA.width - sizeB.width, sizeA.height - sizeB.height);
}

static inline CGFloat NPSizeLength(CGSize size)
{
    return hypot(size.width, size.height);
}

                 
NINEPATCH_EXTERN_END
