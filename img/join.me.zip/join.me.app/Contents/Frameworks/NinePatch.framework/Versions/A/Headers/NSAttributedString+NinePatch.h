//
//  NSAttributedString+NinePatch.h
//  ninepatch
//
//  Created by Károly Lőrentey on 2013-08-29.
//  Copyright (c) 2013 LogMeIn, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSAttributedString (NinePatch)

+ (NSAttributedString *)npAttributedStringWithGlyphName:(NSString *)glyphName inFont:(NSFont *)font;
+ (NSAttributedString *)npAttributedStringWithCharacter:(unichar)c inFont:(NSFont *)font;

@end
